package com.springmvc.roles;

public enum Roles 
{
	Role_Admin,
	Role_User,
	Role_ClubManager,
	Role_StoreManager,
	Role_Teacher
}
